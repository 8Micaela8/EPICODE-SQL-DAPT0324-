
/* Creazione Database*/

CREATE DATABASE ToysGroup_EsercitazioneFinale_Correale;

/* Utilizzo Schema di default */

USE ToysGroup_EsercitazioneFinale_Correale;

/* Creazione delle tabelle. */

CREATE TABLE Product (
	ProductId INT PRIMARY KEY,
    ProductName VARCHAR (100),
    Category VARCHAR(100),
    UnitPrice DECIMAL (50, 2),
    Color VARCHAR (100),
    Age VARCHAR(100));
    
    
   CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50),
    Country VARCHAR(50),
    ShippingMethod VARCHAR(50));
    
    
    CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    SalesAmount DECIMAL (50, 2),
    TransactionDate DATE,
    Quantity INT,
    ProductId INT,
    RegionId INT,
	FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId)
);

/* Popolamento delle tabelle con i relativi dati. */

INSERT INTO Product (ProductID, ProductName, Category, UnitPrice, Color, Age) VALUES
(1, 'Puzzle', 'Educativo', 13.00, 'Rosso', '3+'),
(2, 'Cucine giocattolo', 'Giocattoli in legno', 69.90, 'Multicolore', '3+'),
(3, 'Playstation', 'Videogioco', 849.00, 'Rosso', '18+'),
(4, 'Action figure', 'Supereroi', 19.50, 'Multicolore', '5+'),
(5, 'Gioco puzzle', 'Educativo', 14.50, 'Multicolore', '6+'),
(6, 'Action figure', 'Giocattoli azione', 19.90, 'Blu', '4+'),
(7, 'Cucina giocattolo', 'Gioco di ruolo', 24.90, 'Rosa', '3+'),
(8, 'Mattoncini', 'Costruzione', 59.99, 'Multicolore', '2+'),
(9, 'Set di arti creative', 'Creatività', 34.00, 'Multicolore', '5+'),
(10, 'Strumento musicale', 'Musica', 25.00, 'Multicolore', '4+');

INSERT INTO Region (RegionID, RegionName, Country, ShippingMethod) VALUES
(101, 'Sud America', 'Argentina', 'Sea'),
(102, 'North America', 'USA', 'Air'),
(103, 'Europe', 'Portogallo', 'Sea'),
(104, 'Europe', 'Danimarca', 'Air'),
(105, 'Asia', 'China', 'Air'),
(106, 'Oceania', 'Australia', 'Sea');

INSERT INTO Sales(SalesID, SalesAmount, TransactionDate, Quantity, ProductId, RegionId) VALUES 
(1, 39.00, '2022-05-15', 3, 1, 101),
(2, 279.60, '2021-05-16', 4, 2, 102),
(3, 1698.00, '2022-05-17', 2, 3, 103),
(4, 39.00, '2020-05-18', 2, 4, 104),
(5, 43.50, '2019-05-19', 3, 5, 101),
(6, 79.60, '2018-05-20', 4, 6, 102),
(7, 74.70, '2022-05-21', 3, 7, 103);

/* Inizio interrogazione delle tabelle come da punti richiesti.*/

/* 1. Verificare che i campi definiti come PK siano univoci.*/

SELECT 'ProductID' AS PrimaryKey, COUNT(ProductID) AS DuplicateKey
FROM Product
GROUP BY ProductID
HAVING COUNT(ProductID) > 1;

SELECT 'RegionID' AS PrimaryKey, COUNT(RegionID) AS DuplicateKey
FROM Region
GROUP BY RegionID
HAVING COUNT(RegionID) > 1;

SELECT 'SalesID' AS PrimaryKey, COUNT(SalesID) AS DuplicateKey
FROM Sales
GROUP BY SalesID
HAVING COUNT(SalesID) > 1;


/* 2.Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato (quantità e costo) totale per anno.*/

SELECT p.ProductId, p.ProductName, YEAR(s.TransactionDate) as SalesYear, SUM(s.Quantity * p.UnitPrice) as Revenue
FROM Sales s
JOIN Product p ON s.ProductId = p.ProductId
GROUP BY p.ProductName, YEAR(s.TransactionDate), p.ProductId;


/* 3.Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.*/

SELECT r.RegionId, r.Country, SUM(s.Quantity * p.UnitPrice) as TotalRevenue, YEAR(s.TransactionDate) as SalesYear
FROM Sales s
INNER JOIN Region r ON s.RegionId = r.RegionId
INNER JOIN Product p ON s.ProductId = p.ProductId
GROUP BY SalesYear, r.RegionId
ORDER BY SalesYear DESC, TotalRevenue DESC;


/* 4.Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT p.Category, SUM(s.Quantity) as MostSoldCategory
FROM Sales s
INNER JOIN Product p ON s.ProductId = p.ProductID
GROUP BY p.Category
ORDER BY MostSoldCategory DESC
LIMIT 1;

 /* 5.Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.*/
/* Approccio 1 */

SELECT p.ProductId, p.ProductName
FROM Product p 
WHERE p.ProductId NOT IN
(SELECT s.ProductId FROM Sales s);

/* Approccio 2 */

SELECT p.ProductId, p.ProductName
FROM Product p 
LEFT JOIN Sales s ON p.ProductId = s.ProductId
WHERE s.ProductId IS NULL;

/*  6.Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/

SELECT p.ProductName, MAX(s.TransactionDate) AS LastSale
FROM Product p
INNER JOIN Sales s ON p.ProductId = s.ProductId
GROUP BY p.ProductName
ORDER BY LastSale DESC;

